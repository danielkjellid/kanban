//function to load different functions onload.
function onLoad() {
    listMembers();
    listTasks();
    listAssignments();
}